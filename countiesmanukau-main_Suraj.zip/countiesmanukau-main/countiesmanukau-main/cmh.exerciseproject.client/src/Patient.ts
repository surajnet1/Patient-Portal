export type Patient = {
    patientId: number,
    firstName: string,
    lastName: string,
    age: number
}