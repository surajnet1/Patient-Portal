import { Patient } from "./Patient";
//import CryptoJS from 'crypto-js';


export async function getPatients(): Promise<Patient[]> {
    try {
        const response = await request<Patient[]>("Patient/GetPatients");
        return response;
    } catch (error) {
        console.error("An error occurred while fetching patients:", error);
        throw error;
    }
}

//export async function addPatient(patient: Patient, accessKey: string): Promise<void> {
//    try {
//        const encryptedAccessKey = encryptAccessKey(accessKey);
//        await request<void>("Patient/AddPatient", {
//            method: 'POST',
//            headers: {
//                'Content-Type': 'application/json',
//                'Access-Key': encryptedAccessKey 
//            },
//            body: JSON.stringify(patient)
//        });
//    } catch (error) {
//        console.error("An error occurred while adding patient:", error);
//        throw error;
//    }
//}

//function encryptAccessKey(accessKey: string): string {
//    // Perform AES encryption
//    const ciphertext = CryptoJS.AES.encrypt(accessKey, 'secret key').toString();
//    return ciphertext;
//}

export async function searchPatients(name: string): Promise<Patient[]> {
    try {
        const response = await request<Patient[]>(`Patient/SearchPatients?name=${name}`);
        return response;
    } catch (error) {
        console.error(`An error occurred while searching patients with name '${name}':`, error);
        throw error;
    }
}

export async function deletePatient(patientId: number): Promise<void> {
    try {
        await request<void>(`Patient/DeletePatient?patientId=${patientId}`, { method: 'DELETE' });
    } catch (error) {
        console.error(`An error occurred while deleting patient with ID ${patientId}:`, error);
        throw error;
    }
}

export async function addPatient(patient: Patient): Promise<void> {
    try {
        await request<void>("Patient/AddPatient", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patient)
        });
    } catch (error) {
        console.error("An error occurred while adding patient:", error);
        throw error;
    }
}

export async function request<T>(url: string, config: RequestInit = {}): Promise<T> {
    try {
        const response = await fetch(url, config);
        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(`Request failed with status ${response.status}: ${errorMessage}`);
        }
        const data = await response.json();
        return data as T;
    } catch (error) {
        console.error("An error occurred during the request:", error);
        throw error;
    }
}
