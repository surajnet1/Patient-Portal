import { useEffect, useState } from 'react';
import './App.css';
import { Patient } from './Patient';
import { getPatients, addPatient, deletePatient, searchPatients } from './Fetch';

function App() {
    const [patients, setPatients] = useState<Patient[] | undefined>([]);
    const [searchTerm, setSearchTerm] = useState<string>("");
    const [newPatient, setNewPatient] = useState<Patient>({ patientId: 0, firstName: "", lastName: "", age: 0 });
    const [validationError, setValidationError] = useState<string>("");

    useEffect(() => {
        const fetchPatients = async () => {
            try {
                const data = await getPatients();
                setPatients(data || []);
            } catch (error) {
                console.error("An error occurred while fetching patients:", error);
            }
        };
        fetchPatients();
    }, []);

    const handleAddPatient = async () => {
        if (!newPatient.firstName || !newPatient.lastName || newPatient.age === 0) {
            setValidationError("Please fill in all fields.");
            return;
        }

        try {
            await addPatient(newPatient);
            setValidationError("");
            setNewPatient({ patientId: 0, firstName: "", lastName: "", age: 0 });
            const updatedPatients = await getPatients();
            setPatients(updatedPatients || []);
        } catch (error) {
            console.error("An error occurred while adding patient:", error);
        }
    };

    const handleDeletePatient = async (patientId: number) => {
        try {
            await deletePatient(patientId);
            const updatedPatients = patients?.filter(patient => patient.patientId !== patientId);
            setPatients(updatedPatients);
        } catch (error) {
            console.error(`An error occurred while deleting patient with ID ${patientId}:`, error);
        }
    };

    const handleSearchPatient = async () => {
        try {
            const data = await searchPatients(searchTerm);
            setPatients(data || []);
        } catch (error) {
            console.error(`An error occurred while searching patients with name '${searchTerm}':`, error);
        }
    };

    const handleSearchInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(event.target.value);
    };

    return (
        <div>
            <h1 id="tabelLabel">Patient Application</h1>
            <input type="text" placeholder="Search name" value={searchTerm} onChange={handleSearchInputChange} />
            <button onClick={handleSearchPatient}>Search</button>
            <div className="validation-error">{validationError}</div>
            <table className="table table-striped" aria-labelledby="tabelLabel">
                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {patients && patients.map(patient =>
                        <tr key={patient.patientId}>
                            <td>{patient.patientId}</td>
                            <td>{patient.firstName}</td>
                            <td>{patient.lastName}</td>
                            <td>{patient.age}</td>
                            <td><button onClick={() => handleDeletePatient(patient.patientId)}>Delete</button></td>
                        </tr>
                    )}
                    <tr>
                        <td>&nbsp;</td>
                        <td><input type="text" placeholder="Enter first name" value={newPatient.firstName} onChange={(e) => setNewPatient({ ...newPatient, firstName: e.target.value })} /></td>
                        <td><input type="text" placeholder="Enter last name" value={newPatient.lastName} onChange={(e) => setNewPatient({ ...newPatient, lastName: e.target.value })} /></td>
                        <td><input type="number" placeholder="Enter Age" value={newPatient.age} onChange={(e) => setNewPatient({ ...newPatient, age: parseInt(e.target.value) })} /></td>
                        <td><button onClick={handleAddPatient}>Add</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
}

export default App;
