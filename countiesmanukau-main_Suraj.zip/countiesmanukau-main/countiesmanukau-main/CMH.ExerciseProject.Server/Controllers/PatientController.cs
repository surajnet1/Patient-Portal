using CMH.ExerciseProject.Server.Database;
using CMH.ExerciseProject.Server.Model;
using Microsoft.AspNetCore.Mvc;

namespace CMH.ExerciseProject.Server.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class PatientController : ControllerBase
    {
        private readonly IPatientDataLayer _patientDataLayer;

        public PatientController(IPatientDataLayer patientDataLayer)
        {
            _patientDataLayer = patientDataLayer ?? throw new ArgumentNullException(nameof(patientDataLayer));
        }

        [HttpGet]
        public async Task<IEnumerable<Patient>> SearchPatients(string name)
        {
            try
            {
                var patients = await _patientDataLayer.SearchPatients(name);
                return patients;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"An error occurred while searching patients: {ex.Message}");
                throw;
            }
        }

        [HttpGet]
        public async Task<IEnumerable<Patient>> GetPatients()
        {
            try
            {
                var patients = await _patientDataLayer.GetPatients();
                return patients;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"An error occurred while retrieving patients: {ex.Message}");
                throw;
            }
        }

        [HttpPost]
        public async Task<int> AddPatient(Patient patient)
        {
            try
            {
                return await _patientDataLayer.AddPatient(patient);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"An error occurred while adding the patient: {ex.Message}");
                throw;
            }
        }

        [HttpDelete]
        public async Task<int> DeletePatient(int patientId)
        {
            try
            {
                return await _patientDataLayer.DeletePatient(patientId);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"An error occurred while deleting the patient: {ex.Message}");
                throw;
            }
        }

        //private static IActionResult HandleDataLayerException(Exception ex)
        //{
        //    // this is the logic to handle specific data layer exceptions
        //    // and return appropriate HTTP status codes with informative messages
        //    // not enough time to implement this - Suraj
        //}
    }
}