﻿using CMH.ExerciseProject.Server.Model;

namespace CMH.ExerciseProject.Server.Database
{
    public static class PatientDatabase
    {
        public static List<Patient> Patients { get; set; }
    }
}
