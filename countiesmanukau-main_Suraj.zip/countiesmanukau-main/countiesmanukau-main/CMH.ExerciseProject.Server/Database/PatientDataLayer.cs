﻿using CMH.ExerciseProject.Server.Model;
using System.Security.Cryptography;
namespace CMH.ExerciseProject.Server.Database
{
    public class PatientDataLayer : IPatientDataLayer
    {
        private readonly List<Patient> _patients;
        private readonly string AccessKey = "000Orange^*";
        private readonly IConfiguration _configuration; // IConfiguration field


        public PatientDataLayer(IConfiguration configuration)
        {

            _configuration = configuration; // Inject IConfiguration
            _patients = new List<Patient>();

            // Adding dummy records
            for (int i = 1; i <= 10; i++)
            {
                AddPatient(new Patient { PatientId = i, FirstName = $"suraj-{i}", LastName = "Patel", Age = 30 + i });
            }
        }

        private bool IsValidAccessKey() => _configuration["AccessKey"] == AccessKey; // Retrieve AccessKey from configuration

        public async Task<int> AddPatient(Patient patient)
        {
            if (IsValidAccessKey())
            {
                ArgumentNullException.ThrowIfNull(patient);

                try
                {
                    // Generate a unique PatientId
                    patient.PatientId = await GenerateUniquePatientId();
                    _patients.Add(patient);
                    return await Task.FromResult(patient.PatientId);
                }
                catch (Exception ex)
                {
                    throw new Exception("Error occurred while adding patient to the database.", ex);
                }
            }
            else
            {
                throw new UnauthorizedAccessException("Invalid access key");
            }
        }

        public async Task<int> DeletePatient(int patientId)
        {
            if (IsValidAccessKey())
            {
                ArgumentNullException.ThrowIfNull(patientId);

                try
                {
                    var patientToRemove = _patients.FirstOrDefault(p => p.PatientId == patientId);
                    if (patientToRemove != null)
                        _patients.Remove(patientToRemove);
                    return await Task.FromResult(patientId);
                }
                catch (Exception ex)
                {
                    throw new Exception($"Error occurred while deleting patient with ID {patientId} from the database.", ex);
                }
            }
            else
            {
                throw new UnauthorizedAccessException("Invalid access key");
            }


        }

        public async Task<List<Patient>> GetPatients()
        {
            if (IsValidAccessKey())
            {
                try
                {
                    return await Task.FromResult(_patients);
                }
                catch (Exception ex)
                {
                    throw new Exception("Error occurred while retrieving all patients from the database.", ex);
                }
            }
            else
            {
                throw new UnauthorizedAccessException("Invalid access key");
            }

        }

        public async Task<List<Patient>> SearchPatients(string patientName)
        {
            if (IsValidAccessKey())
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(patientName))
                        return await Task.FromResult(_patients);

                    // Perform case-insensitive search by first name or last name
                    return await Task.FromResult(_patients.Where(p =>
                        p.FirstName.ToLower().Contains(patientName.ToLower()) ||
                        p.LastName.ToLower().Contains(patientName.ToLower())
                    ).ToList());
                }
                catch (Exception ex)
                {
                    throw new Exception($"Error occurred while searching patients with term '{patientName}'.", ex);
                }
            }
            else
            {
                throw new UnauthorizedAccessException("Invalid access key");
            }

        }

        private async Task<int> GenerateUniquePatientId()
        {
            try
            {
                if (_patients.Count == 0)
                    return 1;

                // Generate a unique PatientId by incrementing the maximum PatientId by 1
                return await Task.FromResult(_patients.Max(p => p.PatientId) + 1);
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred while generating unique PatientId.", ex);
            }
        }

        private string EncryptAccessKey(string accessKey)
        {
            // Perform AES encryption
            using (Aes aesAlg = Aes.Create())
            {
                // Set AES key and IV
                //aesAlg.Key = _configuration["EncryptionKey"];
                // aesAlg.IV = _configuration["EncryptionIV"];

                // Create an encryptor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(accessKey);
                        }
                    }
                    return Convert.ToBase64String(msEncrypt.ToArray());
                }
            }
        }

        private string DecryptAccessKey(string encryptedAccessKey)
        {
            // Perform AES decryption
            using (Aes aesAlg = Aes.Create())
            {
                // Set AES key and IV
                //aesAlg.Key = _configuration["EncryptionKey"];
                // aesAlg.IV = _configuration["EncryptionIV"];

                // Create a decryptor to perform the stream transform.
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(encryptedAccessKey)))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            return srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}