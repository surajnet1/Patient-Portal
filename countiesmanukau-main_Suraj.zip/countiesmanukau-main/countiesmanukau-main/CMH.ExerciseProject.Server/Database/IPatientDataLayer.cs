﻿using CMH.ExerciseProject.Server.Model;

namespace CMH.ExerciseProject.Server.Database
{
    public interface IPatientDataLayer
    {
        Task<List<Patient>> GetPatients();
        Task<List<Patient>> SearchPatients(string patientName);
        Task<int> AddPatient(Patient patient);
        Task<int> DeletePatient(int patientId);

    }
}